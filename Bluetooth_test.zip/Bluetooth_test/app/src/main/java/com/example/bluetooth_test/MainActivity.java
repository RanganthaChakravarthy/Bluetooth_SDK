package com.example.bluetooth_test;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    CheckBox enable_cb, visible_cb;
    ListView search_lv;
    ImageView srcimg_iv;
    TextView mybtname_tv;

    private BluetoothAdapter bluetoothAdapter;
    private Set<BluetoothDevice> pairedDevices;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enable_cb = findViewById(R.id.enable_cb);
        visible_cb = findViewById(R.id.visible_cb);
        search_lv = findViewById(R.id.search_lv);
        srcimg_iv = findViewById(R.id.srcimg_iv);
        mybtname_tv = findViewById(R.id.mybtname_tv);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        // To check for proper Bluetooth support
        if (bluetoothAdapter == null) {
            finish();
        }

        mybtname_tv.setText(getLocalBluetoothName());
        // Register for system Bluetooth events
        if (bluetoothAdapter.isEnabled()) {
            Log.d(TAG, "Bluetooth is already enabled");
            //bluetoothAdapter.enable();
            enable_cb.setChecked(true);
        }

        //This is for enabling bluetooth by checking the status of the Enable checkbox
        enable_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    bluetoothAdapter.disable();
                    Log.d(TAG, "Bluetooth Turned OFF");
                    Toast.makeText(MainActivity.this, "Bluetooth Turned OFF", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intenton = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intenton,0);
                    Log.d(TAG, "Enabling Bluetooth");
                    Toast.makeText(MainActivity.this, "Enabling Bluetooth", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //This is for setting the device in discoverable mode for two minutes
        visible_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Intent getVisible = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(getVisible,0);
                    Log.d(TAG, "Visible for 2 min");
                    Toast.makeText(MainActivity.this, "Visible for 2 min", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*
        On Click event of the image calls the getList() method to populate the listview with the unpaired devices
         */
        srcimg_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getList();
            }
        });


        }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getList() {
        pairedDevices = bluetoothAdapter.getBondedDevices();
        ArrayList search_list = new ArrayList();

        for (BluetoothDevice bt_dev : pairedDevices){
            search_list.add(bt_dev.getName());
            Log.d(TAG, "Device name : " + bt_dev.getName() + " : " + bt_dev.getAddress());
        }

        Toast.makeText(this, "Showing devices", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "Populating paired device List");
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,search_list);
        search_lv.setAdapter(adapter);

    }

    public String getLocalBluetoothName(){
        if(bluetoothAdapter == null){
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        String bluetoothname = bluetoothAdapter.getName();
        if (bluetoothname == null){
            bluetoothname = bluetoothAdapter.getAddress();
        }
        return bluetoothname;
    }
}
