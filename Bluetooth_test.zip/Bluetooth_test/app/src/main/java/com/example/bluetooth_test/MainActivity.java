package com.example.bluetooth_test;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private static final String TAG = MainActivity.class.getSimpleName();

    CheckBox enable_cb;
    ListView search_lv;
    ImageView srcimg_iv;
    TextView mybtname_tv;
    Button bt_send, bt_con;
    EditText message_et;

    private static final UUID MY_UUID =
            UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice pairedDevices;
    public ArrayList<BluetoothDevice> search_list = new ArrayList<>();
    public ArrayList pairedSearch_list = new ArrayList();

    BluetoothConnectionService mBluetoothConnection;

    // Create a BroadcastReceiver for ACTION_FOUND.
    private final BroadcastReceiver brd_st_receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(bluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, bluetoothAdapter.ERROR);

                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(TAG, "onReceive: STATE OFF");
                        Toast.makeText(MainActivity.this, "BLUETOOTH STATE OFF", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(TAG, "brd_st_receiver: STATE TURNING OFF");
                        Toast.makeText(MainActivity.this, "BLUETOOTH STATE TURNING OFF", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(TAG, "brd_st_receiver: STATE ON");
                        Toast.makeText(MainActivity.this, "BLUETOOTH STATE ON", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(TAG, "brd_st_receiver: STATE TURNING ON");
                        Toast.makeText(MainActivity.this, "BLUETOOTH STATE TURNING ON", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }
    };

    /**
     * Broadcast Receiver for changes made to bluetooth states such as:
     * 1) Discoverability mode on/off or expire.
     */
    private final BroadcastReceiver brd_vis_receiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {

                int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);

                switch (mode) {
                    //Device is in Discoverable Mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "brd_vis_receiver: Discoverability Enabled.");
                        Toast.makeText(MainActivity.this, "Discoverability Enabled", Toast.LENGTH_SHORT).show();
                        break;
                    //Device not in discoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "brd_vis_receiver: Discoverability Disabled. Able to receive connections.");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "brd_vis_receiver: Discoverability Disabled. Not able to receive connections.");
                        Toast.makeText(MainActivity.this, "Discoverability Disabled", Toast.LENGTH_SHORT).show();
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(TAG, "brd_vis_receiver: Connecting....");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "brd_vis_receiver: Connected.");
                        break;
                }

            }
        }
    };
    /*
    This method is for listing devices which are not yet paired. Broadcast receiver
     */
    private BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            if (action.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
                search_list.add(device);
                pairedSearch_list.add(device.getName());
                Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                ArrayAdapter adapter = new ArrayAdapter<String>(context,android.R.layout.simple_list_item_1,pairedSearch_list);
                search_lv.setAdapter(adapter);
            }
        }
    };
    private final BroadcastReceiver bondRegister = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if(action.equals(BluetoothDevice.ACTION_BOND_STATE_CHANGED)){
                BluetoothDevice bond_dev = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                //If the device is already bonded
                if(bond_dev.getBondState() == BluetoothDevice.BOND_BONDED){
                    Log.d(TAG,"Bondregister : Device Bonded");
                    pairedDevices = bond_dev;
                    Log.d(TAG,"Paired Device : " + pairedDevices);
                }
                if(bond_dev.getBondState() == BluetoothDevice.BOND_BONDING){
                    Log.d(TAG,"Bondregister : Device Bonding");
                }
                if(bond_dev.getBondState() == BluetoothDevice.BOND_NONE){
                    Log.d(TAG,"Bondregister : Device None");
                }
            }

        }
    } ;

    @Override
    protected void onDestroy() {
        Log.d(TAG, "On Destroy Method called");
        super.onDestroy();
        // Unregister the ACTION_FOUND receiver.
        unregisterReceiver(brd_st_receiver);
        unregisterReceiver(brd_vis_receiver);
        unregisterReceiver(broadcastreceiver);
        unregisterReceiver(bondRegister);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enable_cb = findViewById(R.id.enable_cb);
        search_lv = findViewById(R.id.search_lv);
        srcimg_iv = findViewById(R.id.srcimg_iv);
        mybtname_tv = findViewById(R.id.mybtname_tv);
        bt_send = findViewById(R.id.bt_send);
        bt_con = findViewById(R.id.bt_con);
        message_et = findViewById(R.id.message_et);
        //search_list = new ArrayList<>();

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        search_lv.setOnItemClickListener(MainActivity.this);

        // To check for proper Bluetooth support
        if (bluetoothAdapter == null) {
            finish();
        }

        mybtname_tv.setText(getLocalBluetoothName());
        // Register for system Bluetooth events
        if (bluetoothAdapter.isEnabled()) {
            Log.d(TAG, "Bluetooth is already enabled");
            //bluetoothAdapter.enable();
            enable_cb.setChecked(true);
        }

        //This is for enabling bluetooth by checking the status of the Enable checkbox
        enable_cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    bluetoothAdapter.disable();
                    Log.d(TAG, "Bluetooth Turned OFF");
                    Toast.makeText(MainActivity.this, "Bluetooth Turned OFF", Toast.LENGTH_SHORT).show();
                    IntentFilter receiver_intent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
                    registerReceiver(brd_st_receiver,receiver_intent);
                }
                else{
                    Intent intenton = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intenton,0);
                    Log.d(TAG, "Enabling Bluetooth");
                    Toast.makeText(MainActivity.this, "Enabling Bluetooth", Toast.LENGTH_SHORT).show();

                    IntentFilter receiver_intent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
                    registerReceiver(brd_st_receiver,receiver_intent);
                }
                if(isChecked) {
                    //This is for setting the device in discoverable mode for two minutes
                    Intent getVisible = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(getVisible, 0);
                    Log.d(TAG, "Visible for 2 min");
                    Toast.makeText(MainActivity.this, "Visible for 2 min", Toast.LENGTH_SHORT).show();
                }

                IntentFilter visible_intent = new IntentFilter(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
                registerReceiver(brd_vis_receiver,visible_intent);
            }
        });

        /*
        On Click event of the image calls the getList() method to populate the listview with the unpaired devices
         */
        srcimg_iv.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                getList();

            }
        });

        IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(broadcastreceiver, discoverDevicesIntent);

        bt_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBTConnection(pairedDevices, MY_UUID);
            }
        });

        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                byte[] bytes = message_et.getText().toString().getBytes(Charset.defaultCharset());
                mBluetoothConnection.write(bytes);
            }
        });

        }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void getList() {
        Log.d(TAG, "Looking for paired/unpaired devices.");
        Toast.makeText(MainActivity.this, "Looking for paired/unpaired devices", Toast.LENGTH_SHORT).show();

        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
            Log.d(TAG, "Canceling discovery.");

            //check BT permissions in manifest
            checkBTPermission();
            //checkRequirement();
            bluetoothAdapter.startDiscovery();
            if(bluetoothAdapter.startDiscovery()){
                Log.d(TAG,"Discovery Started");
            }
        }
        if (!bluetoothAdapter.isDiscovering()) {

            //check BT permissions in manifest
            checkBTPermission();
            //checkRequirement();

            bluetoothAdapter.startDiscovery();
            if(bluetoothAdapter.startDiscovery()){
                Log.d(TAG,"Discovery Started");
            }
        };

        IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(broadcastreceiver, discoverDevicesIntent);

        /*pairedDevices = bluetoothAdapter.getBondedDevices();
        //ArrayList pairedSearch_list = new ArrayList();

        for (BluetoothDevice bt_dev : pairedDevices){

            search_list.add(bt_dev);
            pairedSearch_list.add(bt_dev.getName());
            Log.d(TAG, "Paired Device name : " + bt_dev.getName() + " : " + bt_dev.getAddress());
        }

        Toast.makeText(this, "Showing devices", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "Populating paired device List");
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,pairedSearch_list);
        search_lv.setAdapter(adapter);*/

    }
    /**
     * This method is required for all devices running API23+
     * Android must programmatically check the permissions for bluetooth. Putting the proper permissions
     * in the manifest is not enough.
     *
     * NOTE: This will only execute on versions > LOLLIPOP because it is not needed otherwise.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkBTPermission(){
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1){
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {
                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1); //Any number
            }
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)== PackageManager.PERMISSION_GRANTED){
                Log.d(TAG,"COARSE LOCATION Permission Granted");
            }
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
                Log.d(TAG,"FINE LOCATION Permission Granted");
            }
        }else{
            Log.d(TAG, "checkBTPermissions: No need to check permissions. SDK version < MARSHMELLOW.");
        }
    }

    public String getLocalBluetoothName(){
        if(bluetoothAdapter == null){
            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        String bluetoothname = bluetoothAdapter.getName();
        if (bluetoothname == null){
            bluetoothname = bluetoothAdapter.getAddress();
        }
        return bluetoothname;
    }

    /**
     * starting chat service method
     */
    public void startBTConnection(BluetoothDevice device, UUID uuid){
        Log.d(TAG, "startBTConnection: Initializing RFCOM Bluetooth Connection.");

        mBluetoothConnection.startClient(device,uuid);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //Cancelling discovery to start pairing
        bluetoothAdapter.cancelDiscovery();

        String devicename = search_list.get(position).getName();
        String deviceaddress = search_list.get(position).getAddress();
        Log.d(TAG,"The device : " + devicename + " with address : " + deviceaddress);
        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.JELLY_BEAN){
            Log.d(TAG,"Trying to pair with device: " + devicename);
            search_list.get(position).createBond();
            pairedDevices = search_list.get(position);
            Log.d(TAG,"Paired Devices : " + pairedDevices);

            mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
        }
    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
